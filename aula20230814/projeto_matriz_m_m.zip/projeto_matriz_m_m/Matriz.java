public class Matriz {
    void desenhar(int tamanho) {

    for (int i = 1; i <= tamanho; i++) {
        for (int j = 1; j <= tamanho; j++) {
            if (i == 1 || i == tamanho || j == 1 || j == tamanho || i == tamanho / 2 + 1 || j == tamanho / 2 + 1) {
                System.out.print("* ");
            } else {
                System.out.print("  ");
            }
        }
        System.out.println();
    }
    }
}